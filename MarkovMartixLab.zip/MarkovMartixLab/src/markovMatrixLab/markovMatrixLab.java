package markovMatrixLab;

public class markovMatrixLab {

	public static void main(String[] args) {
		double[][] sample ={{0.15, 0.875, 0.375},
							{0.55, 0.005, 0.225},
							{0.3, 0.12, 0.4}};
		System.out.print(isMarkovMatrix(sample));

	}

	private static boolean isMarkovMatrix(double[][] mat) {
		boolean isMarkov = true;
		double sumCo = 0;
		for(int i = 0; i<mat.length; i++) {
			for(int j=0; j<mat[i].length; j++) {
			sumCo += mat[j][i]; 
			}
				if(sumCo!=1) {
				isMarkov = false;
				}
				sumCo=0;
		}
		return isMarkov;
	}

}
