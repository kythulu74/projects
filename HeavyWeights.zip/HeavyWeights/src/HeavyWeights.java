import java.io.IOException;
import java.util.*;
import java.io.File;

public class HeavyWeights {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		Scanner read = new Scanner(new File("HeavyWeight.txt"));
		String line = read.nextLine();
		int limit = Integer.parseInt(line);
		int sum = 0;
		while(read.hasNextLine()) {
			String weightString = read.nextLine();
			int currentWeight = Integer.parseInt(weightString);
			if(currentWeight>limit) {
				sum++;
			}
		}
		System.out.println("The number of people whose weights exceed the limit is: " + sum);
	}

}
