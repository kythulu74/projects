import java.io.IOException;
import java.io.File;
import java.util.*;

public class LetterBox {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		Scanner read = new Scanner(new File("LetterBox.txt"));
		String line = read.nextLine();
		int limit = Integer.parseInt(line);
		String data = "";
		String letter = "";
		String number ="";
		for(int i =0; i<limit; i++) {
			data=read.nextLine();
			letter=data.substring(0,data.indexOf(" "));
			number=data.substring(data.indexOf(" ")+1);
			int num =Integer.parseInt(number);
			for(int j =0;j<num;j++) {
				for(int x=0;x<num;x++) {
					System.out.print(letter);
				}
				System.out.println();
			}
			
		}
	}

}
