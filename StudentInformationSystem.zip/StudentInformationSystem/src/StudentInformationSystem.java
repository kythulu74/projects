import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentInformationSystem extends JFrame {

	private JPanel contentPane;
	private JTextField textID;
	private JTextField textFirst;
	private JTextField textLast;
	private JTextField textGrade;
	private static ArrayList<Student> list = new ArrayList<Student>();
	private static int index=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentInformationSystem frame = new StudentInformationSystem();
					frame.setVisible(true);
					Scanner scan = new Scanner(new File("StudentInfo.txt"));
					while(scan.hasNextLine()) {
						String line = scan.nextLine();
						String[] arr = line.split(" ");
						String id = arr[0];
						String first = arr[1];
						String last = arr[2];
						int grade = Integer.parseInt(arr[3]);
						String level = arr[4];
						Student s = new Student(id,first,last,level,grade);
						list.add(s);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentInformationSystem() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 803, 604);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Student Information Report");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblTitle.setBounds(229, 43, 331, 48);
		contentPane.add(lblTitle);
		
		JLabel lblID = new JLabel("Student ID");
		lblID.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblID.setBounds(141, 160, 135, 29);
		contentPane.add(lblID);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstName.setBounds(141, 200, 135, 29);
		contentPane.add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLastName.setBounds(141, 240, 135, 29);
		contentPane.add(lblLastName);
		
		JLabel lblGrade = new JLabel("Grade");
		lblGrade.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGrade.setBounds(141, 280, 135, 29);
		contentPane.add(lblGrade);
		
		JLabel lblGradeLevel = new JLabel("Grade Level");
		lblGradeLevel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGradeLevel.setBounds(141, 320, 135, 29);
		contentPane.add(lblGradeLevel);
		
		textID = new JTextField();
		textID.setBounds(293, 166, 338, 20);
		contentPane.add(textID);
		textID.setColumns(10);
		
		textFirst = new JTextField();
		textFirst.setColumns(10);
		textFirst.setBounds(293, 206, 338, 20);
		contentPane.add(textFirst);
		
		textLast = new JTextField();
		textLast.setColumns(10);
		textLast.setBounds(293, 246, 338, 20);
		contentPane.add(textLast);
		
		textGrade = new JTextField();
		textGrade.setColumns(10);
		textGrade.setBounds(293, 286, 338, 20);
		contentPane.add(textGrade);
		
		String[] levels = {"Select One:", "Freshman", "Sophmore", "Junior","Senior"};
		JComboBox comboBox = new JComboBox(levels);
		comboBox.setBounds(293, 325, 338, 22);
		contentPane.add(comboBox);
		
		JButton btnFirst = new JButton("First");
		btnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = 0;
				textID.setText(list.get(index).getStudentID());
				textFirst.setText(list.get(index).getFirstName());
				textLast.setText(list.get(index).getLastName());
				textGrade.setText(list.get(index).getGrade()+"");
				comboBox.setSelectedItem(list.get(index).getGradeLevel());
				
			}
		});
		btnFirst.setBounds(42, 421, 89, 23);
		contentPane.add(btnFirst);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index=index+1;
				if (index>list.size()-1) {
					JOptionPane.showMessageDialog(null, "No More Students");
				}
				textID.setText(list.get(index).getStudentID());
				textFirst.setText(list.get(index).getFirstName());
				textLast.setText(list.get(index).getLastName());
				textGrade.setText(list.get(index).getGrade()+"");
				comboBox.setSelectedItem(list.get(index).getGradeLevel());
			}
		});
		btnNext.setBounds(187, 421, 89, 23);
		contentPane.add(btnNext);
		
		JButton btnPrevious = new JButton("Previous");
		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index=index-1;
				if (index<0) {
					JOptionPane.showMessageDialog(null, "You Cannot Go Back Further");
				}
				textID.setText(list.get(index).getStudentID());
				textFirst.setText(list.get(index).getFirstName());
				textLast.setText(list.get(index).getLastName());
				textGrade.setText(list.get(index).getGrade()+"");
				comboBox.setSelectedItem(list.get(index).getGradeLevel());
			}
		});
		btnPrevious.setBounds(323, 421, 89, 23);
		contentPane.add(btnPrevious);
		
		JButton btnLast = new JButton("Last");
		btnLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index=list.size()-1;
				textID.setText(list.get(index).getStudentID());
				textFirst.setText(list.get(index).getFirstName());
				textLast.setText(list.get(index).getLastName());
				textGrade.setText(list.get(index).getGrade()+"");
				comboBox.setSelectedItem(list.get(index).getGradeLevel());
			}
		});
		btnLast.setBounds(467, 421, 89, 23);
		contentPane.add(btnLast);
		
		JButton btnNew = new JButton("New");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textID.setText("");
				textFirst.setText("");
				textLast.setText("");
				textGrade.setText("");
				comboBox.setSelectedItem(levels[0]);
			}
		});
		btnNew.setBounds(610, 421, 89, 23);
		contentPane.add(btnNew);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textID.getText();
				String first = textFirst.getText();
				String last = textLast.getText();
				int grade = Integer.parseInt(textGrade.getText());
				String level = (String) comboBox.getSelectedItem();
				Student c = new Student(id,first,last,level,grade);
				list.add(c);
			}
		});
		btnSave.setBounds(323, 477, 89, 23);
		contentPane.add(btnSave);
	}
}
