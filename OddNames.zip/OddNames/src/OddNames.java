import java.io.File;
import java.io.IOException;
import java.util.*;

public class OddNames {

	public static void main(String[] args) throws IOException {
		Scanner read = new Scanner(new File("OddNames.txt"));
		String line = read.nextLine();
		int count = Integer.parseInt(line);
		int sum = -1;
		for(int i=0; i<count;i++) {
			String name = read.nextLine();
			if(name.length()%2==1) {
				sum++;
			}
		}
		System.out.println("The sum of odd names is: " + sum);
	}
}