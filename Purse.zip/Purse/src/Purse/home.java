//KYLE FORD WEDNESDAY 6PM
package Purse;

public class home {

	public static void main(String[] args) {
		//PURSES
		Purse p1 = new Purse();
		Purse p2 = new Purse(10,8,20);
		Purse p3 = new Purse(5,12,5);
		Purse p4 = new Purse(20,10,20);
		Purse p5 = new Purse(15,25,40);
		Purse[] purses = {p1,p2,p3,p4,p5};
		
		//ADD TO PURSE 1 
		p1.addQuarters(5);
		p1.addDimes(15);
		p1.addNickles(8);
		
		//ADD TO PURSE 2
		p2.addQuarters(4);
		p2.addDimes(20);
		p2.addNickles(10);
		
		//PRINT PURSES
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		System.out.println(p5);
		
		//PRINT METHOD RESULTS
		System.out.println(highestTotalCoins(purses));
		System.out.println(highestTotalValue(purses));
		System.out.println(highestQuarters(purses));
		System.out.println(totalCoins(purses));
		System.out.println(totalPursesValue(purses));
		
		//EMPTY PURSES IN ARRAY AND PRINT ARRAY
		emptyPurses(purses);
		for(Purse p:purses) {
			System.out.println(p);
		}
		
	}
	//RETURN HIGHEST TOTAL COINS IN A PURSE
	public static int highestTotalCoins(Purse[] list) {
		int highest = 0;
		for(Purse p:list) {
			if (p.totalCoins()>highest){
				highest = p.totalCoins();
			}
		}
		return highest;
	}
	
	//RETURN HIGHEST VALUE IN A PURSE
	public static double highestTotalValue(Purse[] list) {
		double highest = 0;
		for(Purse p:list) {
			if (p.totalValue()>highest){
				highest = p.totalValue();
			}
		}
		return highest;
	}
	
	//RETURN PURSE WITH MOST QUARTERS
	public static Purse highestQuarters(Purse[] list) {
		int highest = 0;
		Purse quarterPurse = null;
		for(Purse p:list) {
			if (p.getQuarters()>highest){
				highest = p.getQuarters();
				quarterPurse = p;
			}
		}
		return quarterPurse;
	}
	
	//RETURN TOTAL COINS IN ARRAY
	public static int totalCoins(Purse[] list) {
		int total = 0;
		for(Purse p:list) {
			total += p.totalCoins();
		}
		return total;
	}
	
	//RETURN TOTAL VALUE IN ARRAY
	public static double totalPursesValue(Purse[] list) {
		double total = 0;
		for(Purse p:list) {
			total += p.totalValue();
		}
		return total;
	}
	
	//EMPTY ALL PURSES IN THE ARRAY
	public static void emptyPurses(Purse[] list) {
		for(Purse p:list) {
			p.setQuarters(0);
			p.setDimes(0);
			p.setNickles(0);
		}
	}
	
}
