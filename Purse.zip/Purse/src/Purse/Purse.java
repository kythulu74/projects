package Purse;

public class Purse {
		
		//VARIABLES
		private int quarters;
		private int dimes;
		private int nickles;
		
		//CONSTRUCTORS
		public Purse() {
			quarters = 0;
			dimes = 0;
			nickles = 0;
		}
		
		public Purse(int quarter, int dime, int nickle) {
			quarters = quarter;
			dimes = dime;
			nickles = nickle;
		}
		
		//GETTERS
		public int getQuarters() {
			return quarters;
		}
		
		public int getDimes() {
			return dimes;
		}
		
		public int getNickles() {
			return nickles;
		}
		
		//SETTERS
		public void setQuarters(int q) {
			quarters = q;
		}
		
		public void setDimes(int d) {
			dimes = d;
		}
		
		public void setNickles(int n) {
			nickles = n;
		}
		
		//ADDERS
		public void addQuarters(int q) {
			quarters+=q;
		}
		public void addDimes(int d) {
			dimes+=d;
		}
		public void addNickles(int n) {
			nickles+=n;
		}
		
		//METHODS
		public int totalCoins(){
			return quarters+dimes+nickles;
		}
		
		public double totalValue() {
			double total =0;
			total = (0.25*quarters)+(0.10*dimes)+(.05*nickles);
			return total;
		}
		
		public String toString() {
			return "Q: " + quarters + " D: " + dimes + " N: " + nickles;
		}
	}

