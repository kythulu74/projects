import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class PassFail {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		Scanner read = new Scanner(new File("PassFail.txt"));
		String line = read.nextLine();
		String data = "";
		String letter = "";
		String number ="";
		while(read.hasNextLine()) {
			data=read.nextLine();
			letter=data.substring(0,data.lastIndexOf(" "));
			number=data.substring(data.lastIndexOf(" ")+1);
			int num = Integer.parseInt(number);
			if(num<70) {
				System.out.println(letter);
			}
		}
	}
}
