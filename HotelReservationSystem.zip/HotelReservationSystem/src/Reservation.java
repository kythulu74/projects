
public class Reservation {
	
	private String ReservationID, guestName;
	private int nights;
	private double rate;
	
	public Reservation(String reservationID, String guestName, int nights, double rate) {
		super();
		ReservationID = reservationID;
		this.guestName = guestName;
		this.nights = nights;
		this.rate = rate;
	}

	public String getReservationID() {
		return ReservationID;
	}

	public void setReservationID(String reservationID) {
		ReservationID = reservationID;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public int getNights() {
		return nights;
	}

	public void setNights(int nights) {
		this.nights = nights;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Reservation [ReservationID=" + ReservationID + ", guestName=" + guestName + ", nights=" + nights
				+ ", rate=" + rate + "]";
	}
	
	
	
	
}
