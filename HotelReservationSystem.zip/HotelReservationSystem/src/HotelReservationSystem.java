import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class HotelReservationSystem extends JFrame {

	private JPanel contentPane;
	private JTextField textReservationID;
	private JTextField textGuestName;
	private JTextField textNumberOfNights;
	private JTextField textRatePerNight;
	private JTextField textSubtotal;
	private JTextField textTax;
	private JTextField textTotal;
	private static ArrayList<Reservation> list = new ArrayList<Reservation>();
	private static int index = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HotelReservationSystem frame = new HotelReservationSystem();
					frame.setVisible(true);
					Scanner scan = new Scanner(new File("ReservationInfo.txt"));
					while (scan.hasNextLine()) {
						String line = scan.nextLine();
						String[] arr = line.split("-");
						String resID = arr[0];
						String name = arr[1];
						int stay = Integer.parseInt(arr[2]);
						double rate = Double.parseDouble(arr[3]);
						Reservation s = new Reservation(resID, name, stay, rate);
						list.add(s);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HotelReservationSystem() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 912, 619);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblTitle = new JLabel("Cinco Ranch Hotel Reservation");
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitle.setBounds(150, 31, 574, 68);
		contentPane.add(lblTitle);

		JLabel lblReservationID = new JLabel("Reservation ID");
		lblReservationID.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblReservationID.setBounds(98, 170, 112, 26);
		contentPane.add(lblReservationID);

		JLabel lblGuestName = new JLabel("Guest Name");
		lblGuestName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGuestName.setBounds(98, 232, 112, 26);
		contentPane.add(lblGuestName);

		JLabel lblNumberOfNights = new JLabel("Number of Nights");
		lblNumberOfNights.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNumberOfNights.setBounds(98, 298, 112, 26);
		contentPane.add(lblNumberOfNights);

		JLabel lblRatePerNight = new JLabel("Rate per Night");
		lblRatePerNight.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRatePerNight.setBounds(98, 366, 112, 26);
		contentPane.add(lblRatePerNight);

		JLabel lblSubtotal = new JLabel("Subtotal");
		lblSubtotal.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSubtotal.setBounds(508, 170, 112, 26);
		contentPane.add(lblSubtotal);

		JLabel lblTaxes = new JLabel("Tax (6%)");
		lblTaxes.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTaxes.setBounds(508, 240, 112, 26);
		contentPane.add(lblTaxes);

		JLabel lblReservationID_6 = new JLabel("Total");
		lblReservationID_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblReservationID_6.setBounds(508, 306, 112, 26);
		contentPane.add(lblReservationID_6);

		textReservationID = new JTextField();
		textReservationID.setBounds(238, 175, 208, 26);
		contentPane.add(textReservationID);
		textReservationID.setColumns(10);

		textGuestName = new JTextField();
		textGuestName.setColumns(10);
		textGuestName.setBounds(238, 237, 208, 26);
		contentPane.add(textGuestName);

		textNumberOfNights = new JTextField();
		textNumberOfNights.setColumns(10);
		textNumberOfNights.setBounds(238, 303, 208, 26);
		contentPane.add(textNumberOfNights);

		textRatePerNight = new JTextField();
		textRatePerNight.setColumns(10);
		textRatePerNight.setBounds(238, 371, 208, 26);
		contentPane.add(textRatePerNight);

		textSubtotal = new JTextField();
		textSubtotal.setColumns(10);
		textSubtotal.setBounds(608, 175, 208, 26);
		contentPane.add(textSubtotal);

		textTax = new JTextField();
		textTax.setColumns(10);
		textTax.setBounds(608, 242, 208, 26);
		contentPane.add(textTax);

		textTotal = new JTextField();
		textTotal.setColumns(10);
		textTotal.setBounds(608, 303, 208, 26);
		contentPane.add(textTotal);

		JButton btnFirst = new JButton("First");
		btnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = 0;
				String resID = list.get(index).getReservationID();
				String name = list.get(index).getGuestName();
				int nights = list.get(index).getNights();
				double rate = list.get(index).getRate();
				double subtotal = nights * rate;
				double tax = subtotal * .06;
				double total = subtotal + tax;

				textReservationID.setText(resID);
				textGuestName.setText(name);
				textNumberOfNights.setText(nights + "");
				textRatePerNight.setText(rate + "");
				textSubtotal.setText(subtotal + "");
				textTax.setText(tax + "");
				textTotal.setText(total + "");

			}
		});
		btnFirst.setBounds(43, 467, 89, 23);
		contentPane.add(btnFirst);

		JButton btnNext = new JButton(">>");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = index + 1;
				if (index > list.size() - 1) {
					JOptionPane.showMessageDialog(null, "No More Reservations");
				}
				String resID = list.get(index).getReservationID();
				String name = list.get(index).getGuestName();
				int nights = list.get(index).getNights();
				double rate = list.get(index).getRate();
				double subtotal = nights * rate;
				double tax = subtotal * .06;
				double total = subtotal + tax;

				textReservationID.setText(resID);
				textGuestName.setText(name);
				textNumberOfNights.setText(nights + "");
				textRatePerNight.setText(rate + "");
				textSubtotal.setText(subtotal + "");
				textTax.setText(tax + "");
				textTotal.setText(total + "");
			}
		});
		btnNext.setBounds(189, 467, 89, 23);
		contentPane.add(btnNext);

		JButton btnBack = new JButton("<<");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = index - 1;
				if (index <0) {
					JOptionPane.showMessageDialog(null, "This is the first reservation");
				}
				String resID = list.get(index).getReservationID();
				String name = list.get(index).getGuestName();
				int nights = list.get(index).getNights();
				double rate = list.get(index).getRate();
				double subtotal = nights * rate;
				double tax = subtotal * .06;
				double total = subtotal + tax;

				textReservationID.setText(resID);
				textGuestName.setText(name);
				textNumberOfNights.setText(nights + "");
				textRatePerNight.setText(rate + "");
				textSubtotal.setText(subtotal + "");
				textTax.setText(tax + "");
				textTotal.setText(total + "");
			}
		});
		btnBack.setBounds(357, 467, 89, 23);
		contentPane.add(btnBack);

		JButton btnLast = new JButton("Last");
		btnLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = list.size()-1;
				String resID = list.get(index).getReservationID();
				String name = list.get(index).getGuestName();
				int nights = list.get(index).getNights();
				double rate = list.get(index).getRate();
				double subtotal = nights * rate;
				double tax = subtotal * .06;
				double total = subtotal + tax;

				textReservationID.setText(resID);
				textGuestName.setText(name);
				textNumberOfNights.setText(nights + "");
				textRatePerNight.setText(rate + "");
				textSubtotal.setText(subtotal + "");
				textTax.setText(tax + "");
				textTotal.setText(total + "");
			}
		});
		btnLast.setBounds(531, 467, 89, 23);
		contentPane.add(btnLast);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textReservationID.getText();
				String name = textGuestName.getText();
				int nights = Integer.parseInt(textRatePerNight.getText());
				double rate = Double.parseDouble(textRatePerNight.getText());
				double subtotal = nights * rate;
				double tax = subtotal * .06;
				double total = subtotal + tax;

				textSubtotal.setText(subtotal + "");
				textTax.setText(tax + "");
				textTotal.setText(total + "");
				
				Reservation c = new Reservation(id,name,nights,rate);
				list.add(c);
			}
		});
		btnSave.setBounds(705, 467, 89, 23);
		contentPane.add(btnSave);
	}

}
