
public class Tester {

	public static void main(String[] args) {
		
		Ticket my = new Ticket("457",11);
		System.out.println(my);
		
		StudentAdvance stu = new StudentAdvance("24",10);
		System.out.println(stu);
		System.out.println(stu.getPrice());
	}

}
