
public class StudentAdvance extends Ticket {

	//CONSTRUCTOR
	public StudentAdvance(String t, int d) {
		super(t, d);
	}
	
	public int getPrice() {
		return super.getPrice()/2;
	}
	
	public String toString() {
		return super.toString()+"\n(student ID required)";
	}

}
