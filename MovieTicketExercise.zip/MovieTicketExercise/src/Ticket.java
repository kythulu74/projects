
public class Ticket {

	//VARIABLES
	private String ticketNumber;
	private int daysInAdvance;

	//CONSTRUCTORS
	public Ticket(String t, int d) {
		ticketNumber=t;
		daysInAdvance=d;
	}
	
	//GETTERS
	public String getTicketNumber() {
		return ticketNumber;
	}

	public int getDaysInAdvance() {
		return daysInAdvance;
	}
	
	//METHODS
	public int getPrice() {
		int x=getDaysInAdvance()>=10?30:40;
		return x;
	}

	public String toString() {
		return "Number: "+ ticketNumber + "\nPrice: " + getPrice();
	}
	
	
}
